<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Сайт на практику</title>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="owl/css/owl.carousel.min.css">
    <link rel="stylesheet" href="owl/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="mycss/main.css">
    <script src="jquery/jquery-3.7.1.js"></script>
    <script src="owl/js/owl.carousel.min.js"></script>
</head>
<body style="background-color: rgb(235,235,235)">
    <header style="background-color: rgb(255,255,255)" class="shadow">
        <nav class="d-flex justify-content-between">
            <div class="d-flex justify-content-start align-items-center">
                <h2>
                    <a class="text-decoration-none text-dark" href="index.php">Магазин книг</a>
                </h2>
            </div>
            <?php
            session_start();
            
            if ($_SESSION['role'] == 'user') {
                echo '<div class="d-flex align-items-center">
                <a href="pages/cart.php" class="mx-3">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-cart" viewBox="0 0 16 16">
                        <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .491.592l-1.5 8A.5.5 0 0 1 13 12H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5M3.102 4l1.313 7h8.17l1.313-7zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4m7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4m-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2m7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2"/>
                    </svg>
                Корзина
                </a>
                <a href="pages/orders.php" class="mx-3">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-clock-history" viewBox="0 0 16 16">
                        <path d="M8.515 1.019A7 7 0 0 0 8 1V0a8 8 0 0 1 .589.022zm2.004.45a7 7 0 0 0-.985-.299l.219-.976q.576.129 1.126.342zm1.37.71a7 7 0 0 0-.439-.27l.493-.87a8 8 0 0 1 .979.654l-.615.789a7 7 0 0 0-.418-.302zm1.834 1.79a7 7 0 0 0-.653-.796l.724-.69q.406.429.747.91zm.744 1.352a7 7 0 0 0-.214-.468l.893-.45a8 8 0 0 1 .45 1.088l-.95.313a7 7 0 0 0-.179-.483m.53 2.507a7 7 0 0 0-.1-1.025l.985-.17q.1.58.116 1.17zm-.131 1.538q.05-.254.081-.51l.993.123a8 8 0 0 1-.23 1.155l-.964-.267q.069-.247.12-.501m-.952 2.379q.276-.436.486-.908l.914.405q-.24.54-.555 1.038zm-.964 1.205q.183-.183.35-.378l.758.653a8 8 0 0 1-.401.432z"/>
                        <path d="M8 1a7 7 0 1 0 4.95 11.95l.707.707A8.001 8.001 0 1 1 8 0z"/>
                        <path d="M7.5 3a.5.5 0 0 1 .5.5v5.21l3.248 1.856a.5.5 0 0 1-.496.868l-3.5-2A.5.5 0 0 1 7 9V3.5a.5.5 0 0 1 .5-.5"/>
                    </svg>
                Оформленные заказы
                </a>
                <a href="php/quit.php" class="mx-3">
                Выйти
                </a>

            </div>
            ';
            }
            elseif ($_SESSION['role'] == 'admin') {
                echo '<div class="d-flex align-items-center">
                <a href="pages/cart.php" class="mx-3">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-cart" viewBox="0 0 16 16">
                        <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .491.592l-1.5 8A.5.5 0 0 1 13 12H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5M3.102 4l1.313 7h8.17l1.313-7zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4m7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4m-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2m7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2"/>
                    </svg>
                Корзина
                </a>
                <a href="pages/orders.php" class="mx-3">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-clock-history" viewBox="0 0 16 16">
                        <path d="M8.515 1.019A7 7 0 0 0 8 1V0a8 8 0 0 1 .589.022zm2.004.45a7 7 0 0 0-.985-.299l.219-.976q.576.129 1.126.342zm1.37.71a7 7 0 0 0-.439-.27l.493-.87a8 8 0 0 1 .979.654l-.615.789a7 7 0 0 0-.418-.302zm1.834 1.79a7 7 0 0 0-.653-.796l.724-.69q.406.429.747.91zm.744 1.352a7 7 0 0 0-.214-.468l.893-.45a8 8 0 0 1 .45 1.088l-.95.313a7 7 0 0 0-.179-.483m.53 2.507a7 7 0 0 0-.1-1.025l.985-.17q.1.58.116 1.17zm-.131 1.538q.05-.254.081-.51l.993.123a8 8 0 0 1-.23 1.155l-.964-.267q.069-.247.12-.501m-.952 2.379q.276-.436.486-.908l.914.405q-.24.54-.555 1.038zm-.964 1.205q.183-.183.35-.378l.758.653a8 8 0 0 1-.401.432z"/>
                        <path d="M8 1a7 7 0 1 0 4.95 11.95l.707.707A8.001 8.001 0 1 1 8 0z"/>
                        <path d="M7.5 3a.5.5 0 0 1 .5.5v5.21l3.248 1.856a.5.5 0 0 1-.496.868l-3.5-2A.5.5 0 0 1 7 9V3.5a.5.5 0 0 1 .5-.5"/>
                    </svg>
                Оформленные заказы
                </a>
                <a href="pages/new_book.html" class="mx-3">
                Добавить книгу
                </a>
                <a href="php/quit.php" class="mx-3">
                Выйти
                </a>

            </div>
            ';
            }
            else {
                echo '<div class="d-flex align-items-center">
                <a href="pages/login.html" class="mx-3">Войти</a>
                <span>/</span>
                <a href="pages/registrations.html" class="mx-3">Зарегистрироваться</a>
            </div>';
            }
            
            ?>
        </nav>
    </header>
    <div style="background-color: rgb(255,255,255)" class="container col-12 rounded my-5 border shadow">
        <h3 class="text-center mt-2 mb-4">Популярные книги</h3>
        <div>
            <div class="owl-carousel owl-theme" id="slider">
                <?php
include 'db/connect.php';

$query = 'SELECT DISTINCT books.*, orders.id_books, orders.count
          FROM books 
          JOIN orders ON books.id_books = orders.id_books 
          WHERE orders.count > 0
          ORDER BY orders.count DESC';
$result = mysqli_query($conn, $query);
$repeat = [];
if ($result) {
    while ($user = mysqli_fetch_assoc($result)) {
        if (in_array($user["id_books"],$repeat)){
            continue;
        }
        else {
            array_push($repeat,$user["id_books"]);
            echo '<div class="slide">
                     <a href="pages/book_about.php?id='.$user["id_books"].'"><img src="'.$user["photo"].'" width=130 height=150></a>
                    <p  class="fw-bold">'.$user["price"].' Р</p>
                    <p class="text-truncate">'.$user["title"].'</p>
                </div>';
        }
    }
} else {
    echo 'err: ' . mysqli_error($conn);
}
mysqli_close($conn);
?>
            </div>
        </div>
    </div>
    <div style="background-color: rgb(255,255,255)" class="container col-12 rounded my-5 border shadow">
        <h3 class="text-center mt-2 mb-4">Все книги</h3>
        <div class="row">
            <?php
include 'db/connect.php';

$query = 'SELECT * FROM books WHERE id_books';
$result = mysqli_query($conn, $query);

if ($result) {
    while ($user = mysqli_fetch_assoc($result)) {
        echo '<div class="col-lg-2 col-md-3 col-sm-3 col-4">
                <div class="container">
                <a href="pages/book_about.php?id='.$user["id_books"].'"><img src="'.$user["photo"].'" class="img-fluid"></a>
                </div>
                <div>
                <p class="fw-bold">'.$user["price"].'р</p>
                <p class="text-truncate">'.$user["title"].'</p>
                </div>
            </div>';
    }
} else {
    echo 'err: ' . mysqli_error($conn);
}
mysqli_close($conn);
?>
        </div>
    </div>
    <script>$(document).ready(function(){
        const slider = $("#slider").owlCarousel({
            loop:false,
            margin:10,
            responsive: {
                425: {items:3},
                768: {items:5},
                1024: {items:6},
                1180: {items:10}
            }
        });
    });
    </script>
</body>
</html>