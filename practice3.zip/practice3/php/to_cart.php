<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
include '../db/connect.php';

$id_user = $_SESSION["id_user"];

$id_book = $_POST["id_book"];

$count = $_POST["count"];


$stmt = $conn->prepare("INSERT INTO `cart` (`id_user`, `id_books`, `count`) VALUES (?, ?, ?)");
$stmt->bind_param("iii", $id_user, $id_book, $count);

if ($stmt->execute()) {
    echo "ok )";
} else {
    echo "not ok (";
}
mysqli_close($conn);
?>
