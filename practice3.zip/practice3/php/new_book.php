<?php
include '../db/connect.php';

$name = $_FILES['photo']['name'];
$tmp_name = $_FILES['photo']['tmp_name'];

$photo_url = 'img/books_photo/'.$name;

move_uploaded_file($tmp_name, '../img/books_photo/'.$name);

$price = $_POST['price'];
$title = $_POST['title'];

$query="INSERT INTO books (photo,	price,	title) VALUES ('$photo_url', '$price', '$title')";
$result=mysqli_query($conn, $query);
  if ($result){
    mysqli_close($conn);
  }
  else {
    echo "Error";
  }


?>