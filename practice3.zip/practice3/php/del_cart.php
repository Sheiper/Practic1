<?php

include '../db/connect.php';

$id_cart = $_POST["id_cart"];

$query = 'DELETE FROM cart WHERE id_cart = '.$id_cart.'';


$result = mysqli_query($conn, $query);

if ($result) {
    echo "deleted )";
}
else {
    echo "not delete (";
}
mysqli_close($conn);
?>