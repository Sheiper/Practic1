<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
include '../db/connect.php';

$id_user = $_POST["id_user"];

$id_book = $_POST["id_book"];

$count = $_POST["count"];

$order_date = date("Y-m-d");

$date_of_receipt = date("Y-m-d", strtotime("+7 days"));

$order_status = false;

$stmt = $conn->prepare("INSERT INTO `orders` (`order_date`, `date_of_receipt`, `order_status`, `id_user`, `id_books`, `count`) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssiiii", $order_date, $date_of_receipt, $order_status, $id_user, $id_book, $count);

if ($stmt->execute()) {
    echo "ok )";
} else {
    echo "not ok (";
}
mysqli_close($conn);
?>
