<?php
$servername = "localhost";
$username = "i92379zj_user1"; // замените на ваше имя пользователя
$password = "Qwerty123"; // замените на ваш пароль
$dbname = "i92379zj_user1"; // замените на имя вашей базы данных

// Создайте соединение
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверьте соединение
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>