<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Сайт на практику</title>
    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../mycss/main.css">
</head>
<body style="background-color: rgb(235,235,235)">
    <header style="background-color: rgb(255,255,255)" class="shadow">
        <nav class="d-flex justify-content-between">
            <div class="d-flex justify-content-start align-items-center">
                <h2>
                    <a class="text-decoration-none text-dark" href="../index.php">Магазин книг</a>
                </h2>
            </div>
        </nav>
    </header>
    <div style="background-color: rgb(255,255,255)" class="container col-12 rounded my-5 border shadow">
        <h3 class="text-center mt-2 mb-4">Корзина</h3>
        <?php
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

include '../db/connect.php';

$id_user = $_SESSION["id_user"];
$query = 'SELECT cart.*, books.photo, books.price, books.title 
          FROM cart 
          JOIN books ON cart.id_books = books.id_books 
          WHERE cart.id_user = "'.mysqli_real_escape_string($conn, $id_user).'"';

$result = mysqli_query($conn, $query);

if ($result) {
    while ($cart = mysqli_fetch_assoc($result)) {
        echo '
        <div class="d-flex justify-content-between align-items-center">
            <div class="">
                <img src="../'.$cart["photo"].'" width=130 height=150>
                <p class="fw-bold">'.$cart["price"].' р</p>
                <p>'.$cart["title"].'</p>
            </div>
            <div>Количество: '.$cart["count"].'</div>
            <div>
                <form method="POST" action="../php/to_order.php">
                <input type="hidden" name="id_user" value="'.$cart["id_user"].'">
                <input type="hidden" name="id_book" value="'.$cart["id_books"].'">
                <input type="hidden" name="count" value="'.$cart["count"].'">
                <button type="submit" class="btn btn-sm bg-success mx-1 my-1 text-light">Заказать</button>
                </form>
                <form action="../php/del_cart.php" method="POST">
                <input type="hidden" name="id_cart" value="'.$cart["id_cart"].'">
                <button type="submit" class="btn btn-sm bg-danger mx-1 my-1 text-light">Удалить</button>
                </form>
            </div>
        </div>';
    }
} else {
    echo "err(: " . mysqli_error($conn);
}

mysqli_close($conn);
?>
    </div>
</body>
</html>